package com.example.personalfinancetracker.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.personalfinancetracker.data.model.Transaction
import com.example.personalfinancetracker.data.model.TransactionType
import com.example.personalfinancetracker.databinding.FragmentDashboardBinding
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import java.text.NumberFormat
import java.util.Locale

class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: DashboardViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[DashboardViewModel::class.java]

        setupObservers()
        setupChart()
    }

    private fun setupObservers() {
        viewModel.transactions.observe(viewLifecycleOwner) { transactions ->
            updateDashboard(transactions)
        }

        viewModel.monthlyBudget.observe(viewLifecycleOwner) { budget ->
            binding.totalBudget.text = formatCurrency(budget)
        }
    }

    private fun setupChart() {
        binding.expenseChart.apply {
            description.isEnabled = false
            legend.isEnabled = false
            setHoleColor(android.R.color.transparent)
            setTransparentCircleAlpha(0)
            setEntryLabelColor(android.R.color.black)
            setEntryLabelTextSize(12f)
        }
    }

    private fun updateDashboard(transactions: List<Transaction>) {
        val income = transactions.filter { it.type == TransactionType.INCOME }.sumOf { it.amount }
        val expenses = transactions.filter { it.type == TransactionType.EXPENSE }.sumOf { it.amount }
        val balance = income - expenses

        binding.totalIncome.text = formatCurrency(income)
        binding.totalExpense.text = formatCurrency(expenses)
        binding.balance.text = formatCurrency(balance)

        updateChart(income, expenses)
    }

    private fun updateChart(income: Double, expenses: Double) {
        val entries = listOf(
            PieEntry(income.toFloat(), "Income"),
            PieEntry(expenses.toFloat(), "Expenses")
        )

        val dataSet = PieDataSet(entries, "").apply {
            colors = listOf(
                requireContext().getColor(android.R.color.white),
                requireContext().getColor(android.R.color.holo_blue_dark)
            )
            valueTextSize = 12f
            valueTextColor = requireContext().getColor(android.R.color.white)
        }

        binding.expenseChart.data = PieData(dataSet)
        binding.expenseChart.invalidate()
    }

    private fun formatCurrency(amount: Double): String {
        return NumberFormat.getCurrencyInstance(Locale.getDefault()).format(amount)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 