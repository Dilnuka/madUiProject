package com.example.personalfinancetracker.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.personalfinancetracker.data.TransactionRepository
import com.example.personalfinancetracker.data.model.Transaction
import java.util.Calendar

class DashboardViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TransactionRepository(application)
    private val calendar = Calendar.getInstance()

    private val _transactions = MutableLiveData<List<Transaction>>()
    val transactions: LiveData<List<Transaction>> = _transactions

    private val _monthlyBudget = MutableLiveData<Double>()
    val monthlyBudget: LiveData<Double> = _monthlyBudget

    init {
        loadData()
    }

    private fun loadData() {
        loadTransactions()
        loadMonthlyBudget()
    }

    private fun loadTransactions() {
        val currentMonth = calendar.get(Calendar.MONTH)
        val currentYear = calendar.get(Calendar.YEAR)
        _transactions.value = repository.getTransactionsByMonth(currentMonth, currentYear)
    }

    private fun loadMonthlyBudget() {
        _monthlyBudget.value = repository.getMonthlyBudget()
    }

    fun refreshData() {
        loadData()
    }

    fun getCurrency(): String {
        return repository.getCurrency()
    }
} 