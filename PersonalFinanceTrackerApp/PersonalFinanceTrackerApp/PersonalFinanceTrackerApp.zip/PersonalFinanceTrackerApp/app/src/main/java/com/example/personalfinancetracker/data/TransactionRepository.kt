package com.example.personalfinancetracker.data

import android.content.Context
import android.content.SharedPreferences
import com.example.personalfinancetracker.data.model.Transaction
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File
import java.util.Calendar
import java.util.Date

class TransactionRepository(private val context: Context) {
    private val gson = Gson()
    private val transactionsFile = File(context.filesDir, "transactions.json")
    private val type = object : TypeToken<List<Transaction>>() {}.type
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("finance_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MONTHLY_BUDGET = "monthly_budget"
        private const val KEY_CURRENCY = "currency"
        private const val KEY_CATEGORIES = "categories"
    }

    fun getTransactions(): List<Transaction> {
        return if (transactionsFile.exists()) {
            val json = transactionsFile.readText()
            gson.fromJson(json, type) ?: emptyList()
        } else {
            emptyList()
        }
    }

    fun getTransactionsByMonth(month: Int, year: Int): List<Transaction> {
        return getTransactions().filter {
            val cal = Calendar.getInstance()
            cal.time = it.date
            cal.get(Calendar.MONTH) == month && cal.get(Calendar.YEAR) == year
        }
    }

    fun addTransaction(transaction: Transaction) {
        val transactions = getTransactions().toMutableList()
        transactions.add(transaction)
        saveTransactions(transactions)
    }

    fun updateTransaction(id: String, amount: Double, description: String, category: String) {
        val transactions = getTransactions().toMutableList()
        val index = transactions.indexOfFirst { it.id == id }
        if (index != -1) {
            transactions[index] = transactions[index].copy(
                amount = amount,
                description = description,
                category = category
            )
            saveTransactions(transactions)
        }
    }

    fun deleteTransaction(id: String) {
        val transactions = getTransactions().toMutableList()
        transactions.removeIf { it.id == id }
        saveTransactions(transactions)
    }

    fun getTransactionById(id: String): Transaction? {
        return getTransactions().find { it.id == id }
    }

    fun setMonthlyBudget(budget: Double) {
        sharedPreferences.edit().putFloat(KEY_MONTHLY_BUDGET, budget.toFloat()).apply()
    }

    fun getMonthlyBudget(): Double {
        return sharedPreferences.getFloat(KEY_MONTHLY_BUDGET, 0f).toDouble()
    }

    fun setCurrency(currency: String) {
        sharedPreferences.edit().putString(KEY_CURRENCY, currency).apply()
    }

    fun getCurrency(): String {
        return sharedPreferences.getString(KEY_CURRENCY, "$") ?: "$"
    }

    fun getCategories(): List<String> {
        val json = sharedPreferences.getString(KEY_CATEGORIES, "[]")
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun saveCategories(categories: List<String>) {
        val json = gson.toJson(categories)
        sharedPreferences.edit().putString(KEY_CATEGORIES, json).apply()
    }

    fun exportData(): String {
        return gson.toJson(getTransactions())
    }

    fun importData(json: String) {
        val type = object : TypeToken<List<Transaction>>() {}.type
        val transactions = gson.fromJson<List<Transaction>>(json, type)
        saveTransactions(transactions)
    }

    private fun saveTransactions(transactions: List<Transaction>) {
        val json = gson.toJson(transactions)
        transactionsFile.writeText(json)
    }

    fun getSharedPreferences(): SharedPreferences {
        return sharedPreferences
    }
}