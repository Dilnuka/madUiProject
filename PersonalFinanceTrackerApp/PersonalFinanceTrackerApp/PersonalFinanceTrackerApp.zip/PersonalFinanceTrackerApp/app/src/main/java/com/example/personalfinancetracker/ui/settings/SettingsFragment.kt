package com.example.personalfinancetracker.ui.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.fragment.findNavController
import com.example.personalfinancetracker.R
import com.example.personalfinancetracker.databinding.DialogBudgetInputBinding
import com.example.personalfinancetracker.databinding.FragmentSettingsBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: SettingsViewModel

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(this)[SettingsViewModel::class.java]

        setupObservers()
        setupClickListeners()
    }

    private fun setupObservers() {
        viewModel.monthlyBudget.observe(viewLifecycleOwner) { budget ->
            binding.monthlyBudgetText.text = "${viewModel.getCurrency()}${String.format("%.2f", budget)}"
        }
    }

    private fun setupClickListeners() {
        binding.editBudgetButton.setOnClickListener {
            showBudgetDialog()
        }

        binding.manageCategoriesButton.setOnClickListener {
            findNavController().navigate(R.id.action_navigation_settings_to_categoriesFragment)
        }

        binding.exportDataButton.setOnClickListener {
            viewModel.exportData()
            Snackbar.make(binding.root, R.string.data_exported, Snackbar.LENGTH_SHORT).show()
        }

        binding.importDataButton.setOnClickListener {
            showImportDialog()
        }
    }

    private fun showBudgetDialog() {
        val dialogBinding = DialogBudgetInputBinding.inflate(layoutInflater)
        dialogBinding.budgetInput.setText(binding.monthlyBudgetText.text.toString().replace(viewModel.getCurrency(), ""))

        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.set_budget)
            .setView(dialogBinding.root)
            .setPositiveButton(R.string.set) { dialog, _ ->
                val budget = dialogBinding.budgetInput.text.toString().toDoubleOrNull()
                if (budget != null) {
                    viewModel.setMonthlyBudget(budget)
                }
                dialog.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun showImportDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.import_data)
            .setMessage(R.string.import_data_confirmation)
            .setPositiveButton(R.string.import_data) { _, _ ->
                viewModel.importData()
                Snackbar.make(binding.root, R.string.data_imported, Snackbar.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
} 