package com.example.personalfinancetracker.ui.transactions

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.personalfinancetracker.data.TransactionRepository
import com.example.personalfinancetracker.data.model.Transaction
import java.util.Date

class TransactionsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TransactionRepository(application)

    private val _transactions = MutableLiveData<List<Transaction>>()
    val transactions: LiveData<List<Transaction>> = _transactions

    init {
        loadTransactions()
    }

    private fun loadTransactions() {
        _transactions.value = repository.getTransactions()
    }

    fun deleteTransaction(id: String) {
        repository.deleteTransaction(id)
        loadTransactions()
    }

    fun refreshData() {
        loadTransactions()
    }

    fun addTransaction(amount: Double, description: String, category: String) {
        val transaction = Transaction(
            amount = amount,
            description = description,
            category = category,
            date = Date()
        )
        repository.addTransaction(transaction)
        loadTransactions()
    }

    fun updateTransaction(id: String, amount: Double, description: String, category: String) {
        repository.updateTransaction(
            id,
            amount,
            description,
            category
        )
        loadTransactions()
    }

    fun getTransactionById(id: String): Transaction? {
        return repository.getTransactionById(id)
    }
} 