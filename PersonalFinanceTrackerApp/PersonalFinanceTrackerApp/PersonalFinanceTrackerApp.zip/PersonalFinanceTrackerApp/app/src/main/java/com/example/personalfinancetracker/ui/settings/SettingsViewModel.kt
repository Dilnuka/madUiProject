package com.example.personalfinancetracker.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.personalfinancetracker.data.TransactionRepository
import java.io.File

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TransactionRepository(application)

    private val _monthlyBudget = MutableLiveData<Double>()
    val monthlyBudget: LiveData<Double> = _monthlyBudget

    private val _currency = MutableLiveData<String>()
    val currency: LiveData<String> = _currency

    init {
        loadSettings()
    }

    private fun loadSettings() {
        _monthlyBudget.value = repository.getMonthlyBudget()
        _currency.value = repository.getCurrency()
    }

    fun setMonthlyBudget(budget: Double) {
        repository.setMonthlyBudget(budget)
        _monthlyBudget.value = budget
    }

    fun setCurrency(currency: String) {
        repository.setCurrency(currency)
        _currency.value = currency
    }

    fun getCurrency(): String {
        return repository.getCurrency()
    }

    fun exportData() {
        val data = repository.exportData()
        val file = File(getApplication<Application>().filesDir, "finance_data.json")
        file.writeText(data)
    }

    fun importData() {
        val file = File(getApplication<Application>().filesDir, "finance_data.json")
        if (file.exists()) {
            val data = file.readText()
            repository.importData(data)
        }
    }
} 